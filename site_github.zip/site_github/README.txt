Pointer — demo static site

Pages: index.html, about.html, projects.html, team.html, blog.html, contacts.html
Styles: style.css
Scripts: script.js
Assets: assets/hero1.png hero2.png hero3.png (copied from provided images)

Open index.html in browser to view the site.
