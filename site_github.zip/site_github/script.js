// Файл очищен от переходов на языковые страницы

document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', e=>{
      e.preventDefault();
      const id = a.getAttribute('href').slice(1);
      const el = document.getElementById(id);
      if(el) el.scrollIntoView({behavior:'smooth'});
    });
  });
});


// Language dropdown toggle
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.querySelector(".lang-btn");
  const dropdown = document.querySelector(".lang-dropdown");

  if (btn && dropdown) {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      dropdown.style.display =
        dropdown.style.display === "flex" ? "none" : "flex";
    });

    document.addEventListener("click", (e) => {
      if (!btn.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.style.display = "none";
      }
    });
  }
});


// Animated dropdown toggle
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.querySelector(".lang-btn");
  const dropdown = document.querySelector(".lang-dropdown");

  if (btn && dropdown) {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      dropdown.classList.toggle("show");
    });

    document.addEventListener("click", (e) => {
      if (!btn.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove("show");
      }
    });
  }
});
